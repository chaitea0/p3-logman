todo resize vector correcty
do you need an entry ID
reserve to size for master list
functor writing to sort logs, lambdas?

test writing
1. test conversions
2. all error testing
3. same keywords
4. keyword in the category only
5. find last
6. double timestamp
7. very close timestamps
8. out of range for a,b,d,e
9. invalid command